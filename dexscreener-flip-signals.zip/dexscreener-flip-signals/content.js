/*
 * Dexscreener Flip & Signals — content.js
 * Isolated-world content script: builds the on-page Live Signal panel (chart
 * controls + live signal readout, one combined draggable box) and the
 * banner, plays alert sounds, and relays OS-notification / watch-list
 * requests to background.js. Talks to injected.js (page world) only via
 * CustomEvents.
 */
(function () {
  'use strict';

  const BANNER_ID = 'dexflip-banner';
  const WIDGET_ID = 'dexflip-widget';

  // Dragged widget position, in memory only - never chrome.storage. Survives
  // Dexscreener's SPA pair-switches (same page, widget rebuilt by the
  // MutationObserver below) but always resets to the default top-right
  // corner on a real reload, same "always starts predictable" rule the
  // flip toggles already follow.
  let widgetPos = null;

  function injectStyles() {
    if (document.getElementById('dexflip-styles')) return;
    const style = document.createElement('style');
    style.id = 'dexflip-styles';
    style.textContent = `
      #${BANNER_ID} {
        position: fixed;
        top: 16px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2147483001;
        padding: 10px 18px;
        border-radius: 6px;
        font-family: "Courier New", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
        font-weight: 700;
        font-size: 14px;
        letter-spacing: 0.03em;
        background: rgba(4, 10, 8, 0.94);
        border: 1px solid;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.2s ease;
      }
      @keyframes dexflip-banner-pulse {
        0%, 100% { filter: brightness(1); }
        50% { filter: brightness(1.6); }
      }
      #${BANNER_ID}.show { opacity: 1; animation: dexflip-banner-pulse 1.2s ease-in-out 3; }
      #${BANNER_ID}.buy { border-color: #00ff9c; color: #00ff9c; text-shadow: 0 0 6px #00ff9c; box-shadow: 0 0 14px rgba(0, 255, 156, 0.5); }
      #${BANNER_ID}.sell { border-color: #ff2fd0; color: #ff2fd0; text-shadow: 0 0 6px #ff2fd0; box-shadow: 0 0 14px rgba(255, 47, 208, 0.5); }

      #${WIDGET_ID} {
        position: fixed;
        top: 16px;
        right: 16px;
        z-index: 2147483000;
        width: 210px;
        background: rgba(4, 10, 8, 0.94);
        border: 1px solid #00ff9c;
        border-radius: 4px;
        padding: 10px 12px;
        font-family: "Courier New", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
        box-shadow: 0 0 10px rgba(0, 255, 156, 0.35), inset 0 0 12px rgba(0, 255, 156, 0.06);
        color: #00ff9c;
        text-shadow: 0 0 4px rgba(0, 255, 156, 0.55);
      }
      #${WIDGET_ID}::before {
        content: '';
        position: absolute;
        inset: 0;
        pointer-events: none;
        border-radius: 4px;
        background: repeating-linear-gradient(
          to bottom,
          rgba(0, 255, 156, 0.05) 0px,
          rgba(0, 255, 156, 0.05) 1px,
          transparent 1px,
          transparent 3px
        );
      }
      @keyframes dexflip-signal-flash {
        0%, 100% { box-shadow: 0 0 10px rgba(0, 255, 156, 0.35), inset 0 0 12px rgba(0, 255, 156, 0.06); }
        50% { box-shadow: 0 0 26px 6px var(--dexflip-flash-color, #00ff9c), inset 0 0 16px rgba(0, 255, 156, 0.15); }
      }
      #${WIDGET_ID}.dexflip-flash {
        animation: dexflip-signal-flash 1.1s ease-in-out 2;
      }
      #${WIDGET_ID} .dexflip-label {
        color: #00ff9c;
        opacity: 0.8;
        font-size: 10px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        margin-bottom: 6px;
        display: flex;
        justify-content: space-between;
        gap: 6px;
        cursor: grab;
        user-select: none;
      }
      #${WIDGET_ID} .dexflip-label:active { cursor: grabbing; }
      #${WIDGET_ID} .dexflip-label span:first-child { flex-shrink: 0; }
      #${WIDGET_ID} .dexflip-label span:last-child {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: right;
      }
      #${WIDGET_ID} .dexflip-signal-row {
        display: flex;
        align-items: baseline;
        justify-content: space-between;
        margin-bottom: 8px;
      }
      #${WIDGET_ID} .dexflip-signal {
        font-size: 20px;
        font-weight: 800;
        letter-spacing: 0.02em;
      }
      #${WIDGET_ID} .dexflip-signal.buy { color: #00ff9c; text-shadow: 0 0 6px #00ff9c, 0 0 14px rgba(0, 255, 156, 0.6); }
      #${WIDGET_ID} .dexflip-signal.sell { color: #ff2fd0; text-shadow: 0 0 6px #ff2fd0, 0 0 14px rgba(255, 47, 208, 0.6); }
      #${WIDGET_ID} .dexflip-signal.neutral { color: #3d5c50; text-shadow: none; }
      #${WIDGET_ID} .dexflip-confidence {
        font-size: 12px;
        font-weight: 700;
        color: #8fffcf;
      }
      #${WIDGET_ID} .dexflip-bar-track {
        height: 4px;
        border-radius: 2px;
        background: rgba(0, 255, 156, 0.12);
        overflow: hidden;
        margin-bottom: 10px;
      }
      @keyframes dexflip-bar-pulse {
        0%, 100% { filter: brightness(0.85); }
        50% { filter: brightness(1.3); }
      }
      #${WIDGET_ID} .dexflip-bar-fill {
        height: 100%;
        border-radius: 2px;
        transition: width 0.3s ease, background 0.3s ease, box-shadow 0.3s ease;
        animation: dexflip-bar-pulse 1.8s ease-in-out infinite;
      }
      #${WIDGET_ID} .dexflip-metrics {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 4px 10px;
        font-size: 11px;
      }
      #${WIDGET_ID} .dexflip-metrics div span:first-child {
        color: #4d8a72;
      }
      #${WIDGET_ID} .dexflip-metrics div span:last-child {
        float: right;
        color: #b6ffe0;
        font-variant-numeric: tabular-nums;
      }
      #${WIDGET_ID} .dexflip-warming {
        font-size: 11px;
        color: #4d8a72;
        line-height: 1.4;
      }
      #${WIDGET_ID} .dexflip-tf-row {
        display: flex;
        flex-wrap: wrap;
        gap: 4px;
        margin-bottom: 8px;
      }
      #${WIDGET_ID} .dexflip-tf-btn {
        all: unset;
        cursor: pointer;
        font-family: inherit;
        font-size: 10px;
        font-weight: 700;
        color: #4d8a72;
        background: rgba(0, 255, 156, 0.05);
        border: 1px solid rgba(0, 255, 156, 0.3);
        border-radius: 3px;
        padding: 3px 6px;
      }
      #${WIDGET_ID} .dexflip-tf-btn:hover { color: #00ff9c; border-color: #00ff9c; }
      #${WIDGET_ID} .dexflip-tf-btn.active {
        background: rgba(0, 255, 156, 0.18);
        border-color: #00ff9c;
        color: #00ff9c;
        text-shadow: 0 0 4px #00ff9c;
      }
      #${WIDGET_ID} .dexflip-horizon {
        font-size: 10px;
        color: #4d8a72;
        margin-top: 6px;
      }
      #${WIDGET_ID} .dexflip-divider {
        height: 1px;
        background: rgba(0, 255, 156, 0.25);
        margin: 10px 0 8px;
      }
      #${WIDGET_ID} .dexflip-controls-label {
        color: #00ff9c;
        opacity: 0.8;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        margin-bottom: 6px;
      }
      #${WIDGET_ID} .dexflip-controls {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      #${WIDGET_ID} .dexflip-controls button {
        all: unset;
        cursor: pointer;
        box-sizing: border-box;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        color: #b6ffe0;
        background: rgba(0, 255, 156, 0.06);
        border: 1px solid rgba(0, 255, 156, 0.35);
        border-radius: 6px;
        padding: 9px 10px;
        font-family: inherit;
        font-size: 11px;
        font-weight: 700;
        white-space: nowrap;
        transition: background 0.15s, color 0.15s, border-color 0.15s, box-shadow 0.15s;
      }
      #${WIDGET_ID} .dexflip-controls button .dexflip-btn-state {
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0.04em;
        color: #4d8a72;
      }
      #${WIDGET_ID} .dexflip-controls button:hover {
        border-color: #00ff9c;
        box-shadow: 0 0 8px rgba(0, 255, 156, 0.3);
      }
      #${WIDGET_ID} .dexflip-controls button.active {
        background: rgba(0, 255, 156, 0.18);
        border-color: #00ff9c;
        color: #00ff9c;
      }
      #${WIDGET_ID} .dexflip-controls button.active .dexflip-btn-state {
        color: #00ff9c;
        text-shadow: 0 0 4px #00ff9c;
      }
    `;
    document.head.appendChild(style);
  }

  // Standard TA convention: what a timeframe is generally used for. Shown
  // so "confidence" is never floating without context - it's always tied
  // to a stated horizon, not implied.
  const HORIZON_MAP = {
    '1s': 'Scalping (seconds)',
    '1m': 'Scalping (minutes)',
    '5m': 'Intraday / day trading',
    '15m': 'Intraday / day trading',
    '30m': 'Intraday / day trading',
    '1h': 'Swing (hours–days)',
    '2h': 'Swing (hours–days)',
    '4h': 'Swing (hours–days)',
    '6h': 'Swing (hours–days)',
    '12h': 'Swing (hours–days)',
    D: 'Position (weeks+)',
    W: 'Position (weeks+)',
    M: 'Position (months+)',
  };

  function buildWidget() {
    if (document.getElementById(WIDGET_ID)) return;
    const widget = document.createElement('div');
    widget.id = WIDGET_ID;
    widget.innerHTML = `
      <div class="dexflip-label" title="Drag to move"><span>Live Signal</span><span id="dexflip-pair"></span></div>
      <div class="dexflip-tf-row" id="dexflip-tf-row"></div>
      <div class="dexflip-signal-row">
        <span class="dexflip-signal neutral" id="dexflip-signal">—</span>
        <span class="dexflip-confidence" id="dexflip-confidence"></span>
      </div>
      <div class="dexflip-bar-track"><div class="dexflip-bar-fill" id="dexflip-bar" style="width:0%;background:#2d4a3f;"></div></div>
      <div id="dexflip-body"><div class="dexflip-warming">Waiting for chart data…</div></div>
      <div class="dexflip-horizon" id="dexflip-horizon"></div>
      <div class="dexflip-divider"></div>
      <div class="dexflip-controls-label">⚡ Chart Controls</div>
      <div class="dexflip-controls">
        <button data-action="toggleVerticalInvert" title="Invert price scale - numbers stay readable">
          <span>⇅ Price Flip</span><span class="dexflip-btn-state">OFF</span>
        </button>
        <button data-action="toggleColors" title="Swap candle red/green">
          <span>🎨 Swap Colors</span><span class="dexflip-btn-state">OFF</span>
        </button>
        <button data-action="watchPair" title="Get buy/sell alerts for this pair, even when this tab isn't open">
          <span>☆ Watch Pair</span>
        </button>
      </div>
    `;
    if (widgetPos) {
      widget.style.top = `${widgetPos.top}px`;
      widget.style.left = `${widgetPos.left}px`;
      widget.style.right = 'auto';
    }
    document.body.appendChild(widget);

    widget.addEventListener('click', (e) => {
      const tfBtn = e.target.closest('.dexflip-tf-btn');
      if (tfBtn) {
        window.dispatchEvent(new CustomEvent('dexflip:setTimeframe', { detail: { label: tfBtn.dataset.tf } }));
        return;
      }
      const actionBtn = e.target.closest('button[data-action]');
      if (!actionBtn) return;
      const action = actionBtn.dataset.action;
      if (action === 'watchPair') {
        addCurrentPairToWatchList();
        return;
      }
      window.dispatchEvent(new CustomEvent('dexflip:action', { detail: { action } }));
    });

    makeDraggable(widget);
  }

  // Drag the widget by its "Live Signal" header. Position lives in
  // `widgetPos` (in memory only - see the comment at the top of the file),
  // so it carries across an SPA pair-switch but never across a real reload.
  function makeDraggable(widget) {
    const handle = widget.querySelector('.dexflip-label');
    if (!handle) return;
    let dragging = false;
    let startX = 0, startY = 0, startTop = 0, startLeft = 0;

    handle.addEventListener('pointerdown', (e) => {
      dragging = true;
      const rect = widget.getBoundingClientRect();
      startX = e.clientX;
      startY = e.clientY;
      startTop = rect.top;
      startLeft = rect.left;
      widget.style.top = `${startTop}px`;
      widget.style.left = `${startLeft}px`;
      widget.style.right = 'auto';
      handle.setPointerCapture(e.pointerId);
      e.preventDefault();
    });

    handle.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const maxTop = window.innerHeight - widget.offsetHeight - 4;
      const maxLeft = window.innerWidth - widget.offsetWidth - 4;
      const newTop = Math.min(Math.max(4, startTop + (e.clientY - startY)), Math.max(4, maxTop));
      const newLeft = Math.min(Math.max(4, startLeft + (e.clientX - startX)), Math.max(4, maxLeft));
      widget.style.top = `${newTop}px`;
      widget.style.left = `${newLeft}px`;
      widgetPos = { top: newTop, left: newLeft };
    });

    const stopDrag = (e) => {
      dragging = false;
      try { handle.releasePointerCapture(e.pointerId); } catch (err) { /* already released */ }
    };
    handle.addEventListener('pointerup', stopDrag);
    handle.addEventListener('pointercancel', stopDrag);
  }

  function fmt(n) {
    if (n == null || Number.isNaN(n)) return '—';
    const abs = Math.abs(n);
    const digits = abs >= 100 ? 2 : abs >= 1 ? 4 : 8;
    return n.toFixed(digits);
  }

  function renderTimeframeRow(available, active) {
    const row = document.getElementById('dexflip-tf-row');
    if (!row) return;
    if (!available || available.length === 0) {
      row.innerHTML = '';
      return;
    }
    row.innerHTML = available
      .map(
        (tf) =>
          `<button class="dexflip-tf-btn${tf === active ? ' active' : ''}" data-tf="${tf}">${tf}</button>`
      )
      .join('');
  }

  function updateWidget(detail) {
    buildWidget();
    const { signal, confidence, values, votes, pair, timeframe, availableTimeframes, barsCollected } = detail;

    document.getElementById('dexflip-pair').textContent = pair || '';
    renderTimeframeRow(availableTimeframes, timeframe);

    const horizonEl = document.getElementById('dexflip-horizon');
    horizonEl.textContent = timeframe
      ? `${timeframe} candles — ${HORIZON_MAP[timeframe] || 'horizon varies'}`
      : 'Pick a timeframe above';

    const signalEl = document.getElementById('dexflip-signal');
    const confEl = document.getElementById('dexflip-confidence');
    const barEl = document.getElementById('dexflip-bar');
    const bodyEl = document.getElementById('dexflip-body');

    if (!signal) {
      signalEl.textContent = '—';
      signalEl.className = 'dexflip-signal neutral';
      confEl.textContent = '';
      barEl.style.width = '0%';
      barEl.style.background = '#2d4a3f';
      barEl.style.boxShadow = 'none';
      const need = Math.max(0, 30 - (barsCollected || 0));
      bodyEl.innerHTML = `<div class="dexflip-warming">Collecting data: ${barsCollected || 0}/30 bars${need ? ` (${need} more needed)` : ''}</div>`;
      return;
    }

    signalEl.textContent = signal.toUpperCase();
    signalEl.className = `dexflip-signal ${signal === 'buy' ? 'buy' : 'sell'}`;
    confEl.textContent = `${confidence}% confidence`;
    barEl.style.width = `${confidence}%`;
    barEl.style.background = signal === 'buy' ? '#00ff9c' : '#ff2fd0';
    barEl.style.boxShadow = signal === 'buy' ? '0 0 6px #00ff9c' : '0 0 6px #ff2fd0';

    bodyEl.innerHTML = `
      <div class="dexflip-metrics">
        <div><span>Price</span><span>${fmt(values.close)}</span></div>
        <div><span>RSI14</span><span>${fmt(values.rsi14)}</span></div>
        <div><span>EMA9</span><span>${fmt(values.ema9)}</span></div>
        <div><span>EMA21</span><span>${fmt(values.ema21)}</span></div>
        <div><span>MACD hist</span><span>${fmt(values.macdHist)}</span></div>
        <div><span>Votes</span><span>${votes ? `${Object.values(votes).filter((v) => v === (signal === 'buy' ? 'bull' : 'bear')).length}/3` : '—'}</span></div>
      </div>
    `;
  }

  function syncButtons(state) {
    const widget = document.getElementById(WIDGET_ID);
    if (!widget) return;
    const map = {
      toggleVerticalInvert: state.verticalInvert,
      toggleColors: state.colorsSwapped,
    };
    for (const [action, on] of Object.entries(map)) {
      const btn = widget.querySelector(`button[data-action="${action}"]`);
      if (!btn) continue;
      btn.classList.toggle('active', !!on);
      const stateEl = btn.querySelector('.dexflip-btn-state');
      if (stateEl) stateEl.textContent = on ? 'ON' : 'OFF';
    }
  }

  function parsePairFromUrl() {
    // https://dexscreener.com/{chainId}/{pairAddress}
    const parts = location.pathname.split('/').filter(Boolean);
    if (parts.length < 2) return null;
    return { chainId: parts[0], pairAddress: parts[1] };
  }

  function addCurrentPairToWatchList() {
    const pair = parsePairFromUrl();
    if (!pair) {
      showBanner({ signal: null, text: "Couldn't read pair from this URL" });
      return;
    }
    const label = (document.title || pair.pairAddress).split(' | ')[0].trim();
    chrome.runtime.sendMessage({
      type: 'addWatch',
      chainId: pair.chainId,
      pairAddress: pair.pairAddress,
      label,
    });
    showBanner({ signal: 'buy', text: `Watching ${label} in the background`, forceClass: 'buy' });
  }

  let bannerTimer = null;
  function showBanner({ signal, text, forceClass }) {
    injectStyles();
    let banner = document.getElementById(BANNER_ID);
    if (!banner) {
      banner = document.createElement('div');
      banner.id = BANNER_ID;
      document.body.appendChild(banner);
    }
    banner.className = forceClass || (signal === 'sell' ? 'sell' : 'buy');
    banner.textContent = text;
    requestAnimationFrame(() => banner.classList.add('show'));
    if (bannerTimer) clearTimeout(bannerTimer);
    bannerTimer = setTimeout(() => banner.classList.remove('show'), 4000);
  }

  function playSound(signal) {
    try {
      const url = chrome.runtime.getURL(`sounds/${signal}.wav`);
      const audio = new Audio(url);
      audio.volume = 0.6;
      audio.play().catch(() => {});
    } catch (e) {
      /* ignore */
    }
  }

  // Gentle glow-pulse on the floating widget itself, fired the moment a
  // signal actually alerts (same trigger as the sound/banner/OS
  // notification) - so if you only heard the sound, glancing at the widget
  // tells you which pair it was for (the pair is already shown up top).
  function flashWidget(signal) {
    const widget = document.getElementById(WIDGET_ID);
    if (!widget) return;
    widget.style.setProperty('--dexflip-flash-color', signal === 'sell' ? '#ff2fd0' : '#00ff9c');
    widget.classList.remove('dexflip-flash');
    void widget.offsetWidth; // force reflow so back-to-back signals restart the animation
    widget.classList.add('dexflip-flash');
  }

  window.addEventListener('dexflip:state', (e) => syncButtons(e.detail));
  window.addEventListener('dexflip:stance', (e) => updateWidget(e.detail));

  window.addEventListener('dexflip:error', (e) => {
    showBanner({ signal: null, text: e.detail.message, forceClass: 'sell' });
  });

  window.addEventListener('dexflip:signal', (e) => {
    const { signal, values, pair } = e.detail;
    const text = `${signal.toUpperCase()} signal — ${pair} @ ${values.close}`;
    flashWidget(signal);
    chrome.storage.local.get(['settings'], ({ settings }) => {
      const s = settings || { notifications: true, sound: true, banner: true };
      if (s.banner) showBanner({ signal, text });
      if (s.sound) playSound(signal);
    });
    chrome.runtime.sendMessage({
      type: 'signal',
      signal,
      pair,
      values,
      source: 'active-tab',
    });
  });

  function init() {
    injectStyles();
    buildWidget();
    // Ask injected.js for current state in case content.js loaded after it
    window.dispatchEvent(new CustomEvent('dexflip:requestState'));
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Dexscreener is a SPA - re-ensure the widget exists after client-side navigation
  const observer = new MutationObserver(() => {
    if (!document.getElementById(WIDGET_ID)) buildWidget();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
