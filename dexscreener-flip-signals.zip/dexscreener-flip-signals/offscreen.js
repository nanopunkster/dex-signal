/*
 * Dexscreener Flip & Signals — offscreen.js
 * MV3 service workers have no Audio API, so background alerts (pairs you're
 * watching in the background, tab not open) play sound through this hidden
 * offscreen document instead.
 */
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'playSound' && msg.signal) {
    try {
      const audio = new Audio(chrome.runtime.getURL(`sounds/${msg.signal}.wav`));
      audio.volume = 0.6;
      audio.play().catch(() => {});
    } catch (e) {
      /* ignore */
    }
  }
});
