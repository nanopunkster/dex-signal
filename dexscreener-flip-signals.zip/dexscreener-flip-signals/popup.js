/*
 * Dexscreener Flip & Signals — popup.js
 * Manage the background watch list and global alert settings.
 */
(function () {
  'use strict';

  function parsePairUrl(url) {
    try {
      const u = new URL(url.trim());
      if (!u.hostname.includes('dexscreener.com')) return null;
      const parts = u.pathname.split('/').filter(Boolean);
      if (parts.length < 2) return null;
      return { chainId: parts[0], pairAddress: parts[1] };
    } catch (e) {
      return null;
    }
  }

  function timeAgo(ts) {
    if (!ts) return 'never';
    const s = Math.round((Date.now() - ts) / 1000);
    if (s < 60) return `${s}s ago`;
    return `${Math.round(s / 60)}m ago`;
  }

  function statusLine(status) {
    if (!status) return '<span class="status-line dim">Not checked yet</span>';
    if (status.error) return `<span class="status-line err">${status.error} · ${timeAgo(status.lastCheckedAt)}</span>`;
    const bars = status.barsCollected || 0;
    if (bars < 30) {
      return `<span class="status-line dim">Collecting: ${bars}/30 bars · checked ${timeAgo(status.lastCheckedAt)}</span>`;
    }
    if (status.stance) {
      const cls = status.stance.signal === 'buy' ? 'buy' : 'sell';
      return `<span class="status-line ${cls}">${status.stance.signal.toUpperCase()} ${status.stance.confidence}% · checked ${timeAgo(status.lastCheckedAt)}</span>`;
    }
    return `<span class="status-line dim">No clear signal · checked ${timeAgo(status.lastCheckedAt)}</span>`;
  }

  function renderWatchList(list, statusMap) {
    const rows = document.getElementById('watchListRows');
    const empty = document.getElementById('emptyState');
    rows.innerHTML = '';
    if (!list || list.length === 0) {
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';
    for (const pair of list) {
      const key = `${pair.chainId}:${pair.pairAddress}`;
      const row = document.createElement('div');
      row.className = 'row';
      row.innerHTML = `
        <div style="flex:1; min-width:0;">
          <div class="pair-name" title="${pair.label}">${pair.label || pair.pairAddress}</div>
          ${statusLine(statusMap[key])}
        </div>
        <button class="remove-btn" data-chain="${pair.chainId}" data-addr="${pair.pairAddress}">Remove</button>
      `;
      rows.appendChild(row);
    }
    rows.querySelectorAll('.remove-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        chrome.runtime.sendMessage(
          { type: 'removeWatch', chainId: btn.dataset.chain, pairAddress: btn.dataset.addr },
          load
        );
      });
    });
  }

  function load() {
    chrome.runtime.sendMessage({ type: 'getWatchList' }, (list) => {
      chrome.runtime.sendMessage({ type: 'getWatchStatus' }, (statusMap) => {
        renderWatchList(list, statusMap || {});
      });
    });
    chrome.storage.local.get(['settings'], ({ settings }) => {
      const s = settings || { notifications: true, sound: true, banner: true };
      document.getElementById('notifToggle').checked = !!s.notifications;
      document.getElementById('soundToggle').checked = !!s.sound;
      document.getElementById('bannerToggle').checked = !!s.banner;
    });
  }

  document.getElementById('addBtn').addEventListener('click', () => {
    const input = document.getElementById('pasteUrl');
    const pair = parsePairUrl(input.value);
    if (!pair) {
      input.style.borderColor = '#f23645';
      return;
    }
    input.style.borderColor = '';
    chrome.runtime.sendMessage(
      {
        type: 'addWatch',
        chainId: pair.chainId,
        pairAddress: pair.pairAddress,
        label: `${pair.chainId}/${pair.pairAddress.slice(0, 8)}...`,
      },
      () => {
        input.value = '';
        load();
      }
    );
  });

  function saveSettings() {
    chrome.storage.local.set({
      settings: {
        notifications: document.getElementById('notifToggle').checked,
        sound: document.getElementById('soundToggle').checked,
        banner: document.getElementById('bannerToggle').checked,
      },
    });
  }

  ['notifToggle', 'soundToggle', 'bannerToggle'].forEach((id) => {
    document.getElementById(id).addEventListener('change', saveSettings);
  });

  load();
  setInterval(load, 5000); // keep status fresh while the popup is open
})();
