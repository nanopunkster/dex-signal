/*
 * Dexscreener Flip & Signals — injected.js
 * Runs in the PAGE's own JS world (manifest "world": "MAIN"), so it can see
 * Dexscreener's real TradingView chart object - not just the DOM.
 *
 * Talks to content.js (isolated world, builds the on-page buttons) purely
 * via CustomEvents on `window` - the standard bridge between MAIN and
 * ISOLATED content script worlds. No shared JS objects between the two.
 *
 * IMPORTANT: every toggle here starts OFF on every fresh chart. Nothing is
 * auto-applied from storage. If Dexscreener's SPA swaps to a new pair (new
 * chart instance, same page - no reload), state resets to OFF again so you
 * never end up trading on a flipped view without knowing it.
 */
(function () {
  'use strict';

  const STATE = {
    verticalInvert: false,
    colorsSwapped: false,
  };

  let lastModelRef = null;
  let lastSignalTime = null;
  let pollTimer = null;
  let cachedTimeframes = null;

  function findChart() {
    const iframe = document.querySelector('iframe[id^="tradingview_"]');
    if (!iframe) return null;
    let iwin;
    try {
      iwin = iframe.contentWindow;
      if (!iwin || !iwin.chartWidget || !iwin.chartWidget._model) return null;
    } catch (e) {
      return null;
    }
    const model = iwin.chartWidget._model;
    let series;
    try {
      series = model.mainSeries();
      if (!series) return null;
    } catch (e) {
      return null;
    }
    return { iframe, model, series };
  }

  function resetStateIfNewChart(chart) {
    if (chart.model !== lastModelRef) {
      lastModelRef = chart.model;
      // New chart instance (page just loaded, or SPA navigated to a new pair).
      // Force everything back to OFF/normal - never carry a flip across pairs.
      STATE.verticalInvert = false;
      STATE.colorsSwapped = false;
      lastSignalTime = null;
      cachedTimeframes = null; // re-scan the toolbar for the new chart instance
      broadcastState();
    }
  }

  function broadcastState() {
    window.dispatchEvent(new CustomEvent('dexflip:state', { detail: { ...STATE } }));
  }

  function toggleVerticalInvert(chart) {
    try {
      const ps = chart.series.priceScale();
      chart.model.invertPriceScale(ps);
      STATE.verticalInvert = !STATE.verticalInvert;
    } catch (e) {
      console.warn('[Dexscreener Flip] vertical invert failed', e);
    }
  }

  function toggleColors(chart) {
    try {
      const sp = chart.series.getStyleProperties();
      const pairs = [
        ['upColor', 'downColor'],
        ['borderUpColor', 'borderDownColor'],
        ['wickUpColor', 'wickDownColor'],
      ];
      for (const [a, b] of pairs) {
        if (!sp[a] || !sp[b]) continue;
        const va = sp[a].value();
        const vb = sp[b].value();
        sp[a].setValue(vb);
        sp[b].setValue(va);
      }
      STATE.colorsSwapped = !STATE.colorsSwapped;
    } catch (e) {
      console.warn('[Dexscreener Flip] color swap failed', e);
    }
  }

  window.addEventListener('dexflip:requestState', () => broadcastState());

  window.addEventListener('dexflip:action', (e) => {
    const chart = findChart();
    if (!chart) {
      window.dispatchEvent(
        new CustomEvent('dexflip:error', { detail: { message: 'Chart not ready yet' } })
      );
      return;
    }
    resetStateIfNewChart(chart);
    const action = e.detail && e.detail.action;
    if (action === 'toggleVerticalInvert') toggleVerticalInvert(chart);
    else if (action === 'toggleColors') toggleColors(chart);
    broadcastState();
  });

  // ---- Live signal engine (active-tab path: reads the real chart bars) ----
  function getCandlesFromChart(chart) {
    try {
      const bars = chart.series.bars();
      const fi = bars.firstIndex();
      const li = bars.lastIndex();
      const out = [];
      for (let i = fi; i <= li; i++) {
        const v = bars.valueAt(i);
        if (!v) continue;
        // TradingView internal bar shape: [time_s, open, high, low, close, volume, time_ms]
        out.push({ time: v[0], close: v[4], volume: v[5] });
      }
      return out;
    } catch (e) {
      return [];
    }
  }

  function getPairLabel() {
    return (document.title || 'Dexscreener pair').split(' | ')[0].trim();
  }

  // Reads the chart's own timeframe toolbar (1s/1m/5m/15m/1h/4h/D) and picks
  // whichever one is highlighted TradingView's accent blue - so the widget
  // always matches whatever resolution you've actually got selected, with
  // no separate selector to keep in sync.
  const RES_PATTERN = /^(1s|1m|5m|15m|30m|1h|2h|4h|6h|12h|D|W|M)$/;
  const ACTIVE_COLOR = 'rgb(41, 98, 255)';
  function getTimeframeLabel(chart) {
    try {
      const idoc = chart.iframe.contentDocument;
      const candidates = idoc.querySelectorAll('div,span,button');
      for (const el of candidates) {
        if (el.children.length > 0) continue;
        const t = el.textContent && el.textContent.trim();
        if (!t || !RES_PATTERN.test(t)) continue;
        if (getComputedStyle(el).color === ACTIVE_COLOR) return t;
      }
    } catch (e) {
      /* fall through */
    }
    return null;
  }

  // All timeframe buttons currently in the toolbar (deduped, DOM order).
  function getAvailableTimeframes(chart) {
    if (cachedTimeframes) return cachedTimeframes;
    try {
      const idoc = chart.iframe.contentDocument;
      const candidates = idoc.querySelectorAll('div,span,button');
      const seen = [];
      for (const el of candidates) {
        if (el.children.length > 0) continue;
        const t = el.textContent && el.textContent.trim();
        if (!t || !RES_PATTERN.test(t)) continue;
        if (!seen.includes(t)) seen.push(t);
      }
      if (seen.length) cachedTimeframes = seen;
      return seen;
    } catch (e) {
      return [];
    }
  }

  // Clicks Dexscreener's own toolbar button for that resolution - same as
  // you clicking it. Real click sequence (not just el.click()) so it works
  // whichever way their React handlers are bound.
  function clickTimeframe(chart, label) {
    try {
      const idoc = chart.iframe.contentDocument;
      const iwin = chart.iframe.contentWindow;
      const candidates = idoc.querySelectorAll('div,span,button');
      let target = null;
      for (const el of candidates) {
        if (el.children.length > 0) continue;
        if ((el.textContent || '').trim() === label) {
          target = el;
          break;
        }
      }
      if (!target) return false;
      // Some TradingView toolbars bind the click handler on a parent row;
      // walk up a couple of levels if the leaf itself has no listeners.
      const seq = ['pointerdown', 'mousedown', 'mouseup', 'click'];
      for (const type of seq) {
        const EventCtor = iwin[type.startsWith('pointer') ? 'PointerEvent' : 'MouseEvent'] || MouseEvent;
        target.dispatchEvent(new EventCtor(type, { bubbles: true, cancelable: true, composed: true, view: iwin }));
      }
      return true;
    } catch (e) {
      console.warn('[Dexscreener Flip] timeframe click failed', e);
      return false;
    }
  }

  window.addEventListener('dexflip:setTimeframe', (e) => {
    const chart = findChart();
    if (!chart) return;
    const label = e.detail && e.detail.label;
    if (!label) return;
    clickTimeframe(chart, label);
  });

  function poll() {
    const chart = findChart();
    if (!chart) return;
    resetStateIfNewChart(chart);
    const candles = getCandlesFromChart(chart);
    const timeframe = getTimeframeLabel(chart);
    const availableTimeframes = getAvailableTimeframes(chart);
    const pair = getPairLabel();

    // 1) Always-live widget read - dispatched every tick, even while
    //    warming up, so the widget shows real progress instead of nothing.
    const st = window.DexIndicators.stance(candles);
    window.dispatchEvent(
      new CustomEvent('dexflip:stance', {
        detail: { ...st, pair, timeframe, availableTimeframes, barsCollected: candles.length },
      })
    );

    // 2) One-shot crossover alert (banner/sound/notification) - unchanged.
    if (candles.length < 30) return;
    const result = window.DexIndicators.evaluate(candles);
    if (!result.signal) return;
    if (lastSignalTime === result.values.time) return; // already alerted this bar
    lastSignalTime = result.values.time;
    window.dispatchEvent(
      new CustomEvent('dexflip:signal', {
        detail: { signal: result.signal, values: result.values, pair, source: 'active-tab' },
      })
    );
  }

  function start() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(poll, 5000);
    poll(); // don't wait 5s for the first read
  }

  start();
})();
