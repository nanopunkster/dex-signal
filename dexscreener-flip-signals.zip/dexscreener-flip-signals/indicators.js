/*
 * Dexscreener Flip & Signals — indicator engine
 * Pure math, no DOM/network access. Loaded in three different contexts
 * (page MAIN world, background service worker via importScripts), so it
 * must stay a plain classic script — no import/export.
 *
 * Indicators implemented (the 3 most-cited/standard technical indicators —
 * see the extension's README for sources):
 *   - EMA  (Exponential Moving Average)
 *   - RSI  (Relative Strength Index, Wilder's smoothing, period 14)
 *   - MACD (12, 26, 9 standard settings)
 *
 * These are common technical-analysis tools, not a guarantee of profit.
 * Nothing here is financial advice.
 */
(function (global) {
  'use strict';

  // ---- EMA ----------------------------------------------------------
  function ema(values, period) {
    if (!values || values.length === 0) return [];
    const k = 2 / (period + 1);
    const out = new Array(values.length).fill(null);
    let prev = values[0];
    out[0] = prev;
    for (let i = 1; i < values.length; i++) {
      prev = values[i] * k + prev * (1 - k);
      out[i] = prev;
    }
    return out;
  }

  // ---- RSI (Wilder's smoothing) --------------------------------------
  function rsi(values, period) {
    period = period || 14;
    const out = new Array(values.length).fill(null);
    if (values.length < period + 1) return out;

    let gainSum = 0;
    let lossSum = 0;
    for (let i = 1; i <= period; i++) {
      const diff = values[i] - values[i - 1];
      if (diff >= 0) gainSum += diff;
      else lossSum -= diff;
    }
    let avgGain = gainSum / period;
    let avgLoss = lossSum / period;
    out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);

    for (let i = period + 1; i < values.length; i++) {
      const diff = values[i] - values[i - 1];
      const gain = diff > 0 ? diff : 0;
      const loss = diff < 0 ? -diff : 0;
      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;
      out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
    }
    return out;
  }

  // ---- MACD (12, 26, 9 standard) --------------------------------------
  function macd(values, fast, slow, signal) {
    fast = fast || 12;
    slow = slow || 26;
    signal = signal || 9;
    const emaFast = ema(values, fast);
    const emaSlow = ema(values, slow);
    const macdLine = values.map((_, i) =>
      emaFast[i] != null && emaSlow[i] != null ? emaFast[i] - emaSlow[i] : null
    );
    const validMacd = macdLine.filter((v) => v != null);
    const signalRaw = ema(validMacd, signal);
    // re-align signal line back to full-length array (it starts where macdLine starts)
    const signalLine = new Array(values.length).fill(null);
    let j = 0;
    for (let i = 0; i < macdLine.length; i++) {
      if (macdLine[i] != null) {
        signalLine[i] = signalRaw[j];
        j++;
      }
    }
    const hist = macdLine.map((v, i) =>
      v != null && signalLine[i] != null ? v - signalLine[i] : null
    );
    return { macdLine, signalLine, hist };
  }

  // ---- Full computation over a candle series ---------------------------
  // candles: [{time, close}, ...] ascending by time
  function computeAll(candles) {
    const closes = candles.map((c) => c.close);
    return {
      ema9: ema(closes, 9),
      ema21: ema(closes, 21),
      rsi14: rsi(closes, 14),
      macd: macd(closes, 12, 26, 9),
    };
  }

  // ---- Signal rule (confluence, most recent CLOSED bar only) -----------
  // BUY:  EMA9 crosses above EMA21  AND (RSI rising through 30-50, OR MACD histogram turns positive)
  // SELL: EMA9 crosses below EMA21  AND (RSI falling through 50-70, OR MACD histogram turns negative)
  function evaluate(candles, opts) {
    opts = opts || {};
    const rsiBuyMax = opts.rsiBuyMax != null ? opts.rsiBuyMax : 50;
    const rsiSellMin = opts.rsiSellMin != null ? opts.rsiSellMin : 50;

    if (!candles || candles.length < 30) {
      return { signal: null, reason: 'not-enough-data', values: null };
    }
    const { ema9, ema21, rsi14, macd: m } = computeAll(candles);
    const n = candles.length - 1;
    const p = n - 1;

    if (
      [ema9[n], ema9[p], ema21[n], ema21[p], rsi14[n], m.hist[n]].some(
        (v) => v == null
      )
    ) {
      return { signal: null, reason: 'warming-up', values: null };
    }

    const crossedUp = ema9[p] <= ema21[p] && ema9[n] > ema21[n];
    const crossedDown = ema9[p] >= ema21[p] && ema9[n] < ema21[n];

    const macdTurnedPositive = m.hist[p] != null && m.hist[p] <= 0 && m.hist[n] > 0;
    const macdTurnedNegative = m.hist[p] != null && m.hist[p] >= 0 && m.hist[n] < 0;

    const rsiRising = rsi14[n] > rsi14[p] && rsi14[n] < rsiBuyMax + 20; // avoid buying deep overbought
    const rsiFalling = rsi14[n] < rsi14[p] && rsi14[n] > rsiSellMin - 20;

    const values = {
      ema9: ema9[n],
      ema21: ema21[n],
      rsi14: rsi14[n],
      macdHist: m.hist[n],
      close: candles[n].close,
      time: candles[n].time,
    };

    if (crossedUp && (rsiRising || macdTurnedPositive)) {
      return { signal: 'buy', reason: 'ema-cross-up+confirm', values };
    }
    if (crossedDown && (rsiFalling || macdTurnedNegative)) {
      return { signal: 'sell', reason: 'ema-cross-down+confirm', values };
    }
    return { signal: null, reason: 'no-crossover', values };
  }

  // ---- Live stance (continuous, for the always-visible widget) ---------
  // Not the same as evaluate() above - evaluate() only fires once, on the
  // exact bar a crossover happens (used for alerts/notifications). stance()
  // is the CURRENT read at all times, so the widget always shows something.
  //
  // 3 independent votes, each simply bullish or bearish right now:
  //   - EMA:  ema9 > ema21 ?
  //   - RSI:  rsi14 > 50 ?
  //   - MACD: histogram > 0 ?
  // Confidence = how many of the 3 agree with the majority. With 3 voters
  // that's always 2-of-3 (66%) or 3-of-3 (100%) - there's no invented
  // decimal precision here, just an honest count.
  function stance(candles) {
    if (!candles || candles.length < 30) {
      return { signal: null, confidence: 0, reason: 'not-enough-data', values: null, votes: null };
    }
    const { ema9, ema21, rsi14, macd: m } = computeAll(candles);
    const n = candles.length - 1;

    if ([ema9[n], ema21[n], rsi14[n], m.hist[n]].some((v) => v == null)) {
      return { signal: null, confidence: 0, reason: 'warming-up', values: null, votes: null };
    }

    const votes = {
      ema: ema9[n] > ema21[n] ? 'bull' : 'bear',
      rsi: rsi14[n] > 50 ? 'bull' : 'bear',
      macd: m.hist[n] > 0 ? 'bull' : 'bear',
    };
    const bullCount = Object.values(votes).filter((v) => v === 'bull').length;
    const bearCount = 3 - bullCount;
    const majority = bullCount >= bearCount ? 'bull' : 'bear';
    const agree = majority === 'bull' ? bullCount : bearCount;
    const confidence = Math.round((agree / 3) * 100);

    const values = {
      close: candles[n].close,
      time: candles[n].time,
      ema9: ema9[n],
      ema21: ema21[n],
      rsi14: rsi14[n],
      macdHist: m.hist[n],
    };

    return {
      signal: majority === 'bull' ? 'buy' : 'sell',
      confidence,
      votes,
      values,
      reason: `${agree}/3 indicators agree`,
    };
  }

  global.DexIndicators = { ema, rsi, macd, computeAll, evaluate, stance };
})(typeof window !== 'undefined' ? window : self);
