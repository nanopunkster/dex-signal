/*
 * Dexscreener Flip & Signals — background.js (MV3 service worker)
 *
 * - Holds the watch list (chrome.storage.local) for background monitoring.
 * - Polls api.dexscreener.com once a minute (chrome.alarms minimum period)
 *   for every watched pair, builds our own rolling price history (the public
 *   API has no historical candles, only a live snapshot), and runs the same
 *   EMA/RSI/MACD confluence rule used on the live chart.
 * - Background signals are an approximation of the real chart: 1 price
 *   point per minute, not real OHLC candles. Close, not identical.
 * - Fires OS notifications for both the active-tab path (content.js) and
 *   the background-watch path (this file), and plays sound for the
 *   background path via an offscreen document (service workers can't use
 *   the Audio API directly).
 */
importScripts('indicators.js');

const ALARM_NAME = 'dexflip-poll';
const MAX_HISTORY = 300; // ~5 hours at 1-minute polling

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
  chrome.storage.local.get(['watchList', 'settings', 'pollStatus'], (data) => {
    if (!data.watchList) chrome.storage.local.set({ watchList: [] });
    if (!data.pollStatus) chrome.storage.local.set({ pollStatus: {} });
    if (!data.settings) {
      chrome.storage.local.set({
        settings: { notifications: true, sound: true, banner: true },
      });
    }
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
});

function keyFor(pair) {
  return `${pair.chainId}:${pair.pairAddress}`;
}

async function ensureOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
  });
  if (existing.length > 0) return;
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['AUDIO_PLAYBACK'],
    justification: 'Play buy/sell alert sounds for background-watched pairs',
  });
}

async function notify({ signal, pair, values, settings }) {
  if (settings.notifications) {
    chrome.notifications.create(`dexflip-${Date.now()}`, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: `${signal.toUpperCase()} signal — ${pair}`,
      message: `EMA9/21 cross + confirmation @ ${values.close}`,
      priority: 2,
    });
  }
  if (settings.sound) {
    try {
      await ensureOffscreenDocument();
      chrome.runtime.sendMessage({ type: 'playSound', signal });
    } catch (e) {
      /* offscreen not available, skip sound rather than crash the poll */
    }
  }
}

async function setStatus(key, patch) {
  const { pollStatus } = await chrome.storage.local.get(['pollStatus']);
  const all = pollStatus || {};
  all[key] = { ...(all[key] || {}), ...patch, lastCheckedAt: Date.now() };
  await chrome.storage.local.set({ pollStatus: all });
}

async function pollOnePair(pair, settings) {
  const key = keyFor(pair);
  const url = `https://api.dexscreener.com/latest/dex/pairs/${pair.chainId}/${pair.pairAddress}`;
  let json;
  try {
    const res = await fetch(url);
    json = await res.json();
  } catch (e) {
    await setStatus(key, { error: 'Network error reaching Dexscreener API' });
    return; // network hiccup, try again next minute
  }
  const p = json.pair || (Array.isArray(json.pairs) ? json.pairs[0] : null);
  if (!p || !p.priceUsd) {
    await setStatus(key, { error: 'No price data returned for this pair' });
    return;
  }

  const store = await chrome.storage.local.get(['priceHistory', 'lastSignal']);
  const priceHistory = store.priceHistory || {};
  const lastSignal = store.lastSignal || {};

  const series = priceHistory[key] || [];
  series.push({ time: Date.now(), close: parseFloat(p.priceUsd) });
  if (series.length > MAX_HISTORY) series.splice(0, series.length - MAX_HISTORY);
  priceHistory[key] = series;
  await chrome.storage.local.set({ priceHistory });

  const st = DexIndicators.stance(series);
  await setStatus(key, {
    error: null,
    barsCollected: series.length,
    stance: st.signal ? { signal: st.signal, confidence: st.confidence } : null,
    lastPrice: p.priceUsd,
  });

  if (series.length < 30) return; // ~30 minutes of polling before first possible signal

  const result = DexIndicators.evaluate(series);
  if (!result.signal) return;

  const prev = lastSignal[key];
  if (prev && prev.signal === result.signal && prev.time === result.values.time) return;

  lastSignal[key] = { signal: result.signal, time: result.values.time };
  await chrome.storage.local.set({ lastSignal });

  await notify({ signal: result.signal, pair: pair.label || key, values: result.values, settings });
}

async function pollAllWatched() {
  const { watchList, settings } = await chrome.storage.local.get(['watchList', 'settings']);
  if (!watchList || watchList.length === 0) return;
  const s = settings || { notifications: true, sound: true, banner: true };
  for (const pair of watchList) {
    await pollOnePair(pair, s);
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) pollAllWatched();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'signal' && msg.source === 'active-tab') {
    chrome.storage.local.get(['settings'], ({ settings }) => {
      const s = settings || { notifications: true, sound: true, banner: true };
      // Active tab already showed its own banner+sound (content.js) — just add the OS notification.
      if (s.notifications) {
        chrome.notifications.create(`dexflip-${Date.now()}`, {
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: `${msg.signal.toUpperCase()} signal — ${msg.pair}`,
          message: `EMA9/21 cross + confirmation @ ${msg.values.close}`,
          priority: 2,
        });
      }
    });
    return;
  }

  if (msg.type === 'addWatch') {
    chrome.storage.local.get(['watchList'], ({ watchList }) => {
      const list = watchList || [];
      const exists = list.some(
        (p) => p.chainId === msg.chainId && p.pairAddress === msg.pairAddress
      );
      if (!exists) {
        const newPair = {
          chainId: msg.chainId,
          pairAddress: msg.pairAddress,
          label: msg.label,
          addedAt: Date.now(),
        };
        list.push(newPair);
        chrome.storage.local.set({ watchList: list }, async () => {
          sendResponse({ ok: true });
          // Don't make them wait up to a minute for the alarm - check it now.
          chrome.storage.local.get(['settings'], ({ settings }) => {
            pollOnePair(newPair, settings || { notifications: true, sound: true, banner: true });
          });
        });
      } else {
        sendResponse({ ok: true, alreadyWatched: true });
      }
    });
    return true; // keep sendResponse alive for the async storage call
  }

  if (msg.type === 'removeWatch') {
    const key = keyFor(msg);
    chrome.storage.local.get(
      ['watchList', 'pollStatus', 'priceHistory', 'lastSignal'],
      ({ watchList, pollStatus, priceHistory, lastSignal }) => {
        const list = (watchList || []).filter(
          (p) => !(p.chainId === msg.chainId && p.pairAddress === msg.pairAddress)
        );
        const status = pollStatus || {};
        const history = priceHistory || {};
        const signals = lastSignal || {};
        delete status[key];
        delete history[key];
        delete signals[key];
        chrome.storage.local.set(
          { watchList: list, pollStatus: status, priceHistory: history, lastSignal: signals },
          () => sendResponse({ ok: true })
        );
      }
    );
    return true;
  }

  if (msg.type === 'getWatchList') {
    chrome.storage.local.get(['watchList'], ({ watchList }) => sendResponse(watchList || []));
    return true;
  }

  if (msg.type === 'getWatchStatus') {
    chrome.storage.local.get(['pollStatus'], ({ pollStatus }) => sendResponse(pollStatus || {}));
    return true;
  }
});
